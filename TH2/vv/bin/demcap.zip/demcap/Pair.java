package demcap;
class Pair{
    private int fi,se;
    Pair(int fi,int se){
        this.fi = fi;
        this.se = se;
    }
    public int getValue(){
        return fi;
    }
    public int getCount(){
        return se;
    }
    public void incrementCount(){
        se++;
    }
}
class PS{
    private Stack<Pair> st;
    public PS(){
        st = new Stack<>();
    }
    public long process(int a){
        long res = 0;
        while(!st.empty() && st.peek().getValue() < a){
            res += st.peek().getCount();
            st.pop();
        }
        if(!st.empty()){
            if(st.peek().getValue() == a){
                res += st.peek().getCount();
                st.peek().incrementCount();
                if(st.size() > 1){
                    res ++;
                }
            }
            else {
                res ++;
                st.push(new Pair(a,1));
            }
        }
        else {
            st.push(new Pair(a,1));
        }
        return res;
    }
}