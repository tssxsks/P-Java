package demcap;
import java.util.*;

public class main {
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int n = sc.nextInt();
        PS ps = new PS();
        long res = 0;
        for (int i = 0; i < n ; i++){
            int a = sc.nextInt();
            res += ps.process(a);
        }
        System.out.println(res);
    }
}